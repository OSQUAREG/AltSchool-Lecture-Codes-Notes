

// Naming conventions
//let message = "This is my first message" // ✅
//let message2 = "This is my second message" // ✅
//let user_name = "AdeJ123" // ✅
//let myReallyLongName = "Ade Johnson" // ✅

// let 1message = "This is my first message" // ❌
// let user-name = "AdeJ123" // ❌
// let myreallylongname = "Ade Johnson" // ❌


// Variable declaration (const)
// const NAME = "Ade Johnson"
//NAME = "Adewale Johnson" //❌ //error, cannot re-assign to a constant variable

//const NAME = "Ade Johnson" // ✅
//const name = "Ade Johnson" // ❌

//const MY_BIRTHDAY = "5th July 2000" // ✅
//const MYBIRTHDAY = "5th July 2000" // ❌

// Variable declaration (let)
//let name = "Ade Johnson"
//name = "Adewale Johnson" //✅

//const myBirthday = "5th July 2000" // ✅
//const mybirthday = "5th July 2000" // ❌